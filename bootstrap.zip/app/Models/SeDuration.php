<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeDuration extends Model
{
    use HasFactory;

    protected  $table = 'se_duration';
    protected $fillable = [
        'title',

    ];
}
