<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css" integrity="sha512-In/+MILhf6UMDJU4ZhDL0R0fEpsp4D3Le23m6+ujDWXwl3whwpucJG1PEmI3B07nyJx+875ccs+yX2CqQJUxUw==" crossorigin="anonymous" referrerpolicy="no-referrer" />o
<style>
    .dropify-wrapper{
        line-height: 46px!important;
    }

    .loader {
        border: 16px solid #f3f3f3; /* Light grey */
        border-top: 16px solid #3498db; /* Blue */
        border-radius: 50%;
        width: 120px;
        height: 120px;
        animation: spin 2s linear infinite;
    }

    @keyframes  spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

</style>
<form class="px-10" novalidate="novalidate" id="kt_form2" method="post" action="<?php echo e(url('AnswerLevelDetails')); ?>"
      enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<!--begin: Wizard Step 1-->
    <div class="mb-10">
        <label class="form-label fs-6 fw-bold" >السؤال</label>
        <input rows="5" class="form-control form-control-lg form-control-solid"value="<?php echo e($data->title); ?>">
    </div>
    <?php if( isset($data->date) & $data->date != ''): ?>
        <div class="mb-10">
        <label class="form-label fs-6 fw-bold" >التاريخ</label>
        <input rows="5" class="form-control form-control-lg form-control-solid"value="<?php echo e($data->date); ?>">
    </div>
    <?php endif; ?>
    <br>
        <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
    <?php if($data->question_type == 1 ): ?>
        <div class="mb-10">
            <label class="form-label fs-6 fw-bold">الاجابة</label>
            <textarea rows="5" name="answer" class="form-control form-control-lg form-control-solid"><?php echo e($data->answer); ?></textarea>
        </div>

        <?php elseif($data->question_type == 2 ): ?>
        <?php
        $a = str_replace('[', "" ,$data->values);
        $b = str_replace(']', "" ,$a);

        $answers = explode(',', $b);

        ?>
            <div class="mb-10">
            <label class="form-label fs-6 fw-bold">الاجابة</label>
            <select class="form-control " name="answer">
                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  <?php if($data1 == $data->answer ): ?> selected <?php endif; ?> value="<?php echo e($data1); ?>"><?php echo e($data1); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <?php elseif($data->question_type == 3 ): ?>
        <div class="mb-10">
            <label>الاجابة</label>
            <?php
            $a = str_replace('[', "" ,$data->values);
            $b = str_replace(']', "" ,$a);

            $answers = explode(',', $b);

            ?>
            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="form-label fs-6 fw-bold"><?php echo e($data1); ?></label>
                <input value="<?php echo e($data1); ?>" <?php if(is_array($data1 ,$answers) ): ?>checked  <?php endif; ?> type="checkbox" name="asnwer[]" class="form-control form-control-lg form-control-solid">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php elseif($data->question_type == 4 ): ?>
        <div class="mb-10">
            <!--begin::Label-->
            <label class="col-lg-4 col-form-label fw-bold fs-6">صورة</label>
            <!--end::Label-->
            <!--begin::Col-->
            <div class="col-lg-8">
                <!--begin::Image input-->
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-block">
                            <h4 class="card-title"></h4>
                            <div class="controls">
                                <input type="file" id="input-file-now" class="dropify"  name="img" data-default-file="" required data-validation-required-message="<?php echo e(trans('word.This field is required')); ?>"/>
                            </div>
                        </div>
                    </div>
                    <!--end::Image input-->
                    <!--begin::Hint-->
                
                <!--end::Hint-->
                </div>
                <!--end::Image input-->
                <!--begin::Hint-->

                <!--end::Hint-->
            </div>
            <!--end::Col-->
        </div>


        <?php elseif($data->question_type == 5 ): ?>

        <div class="mb-10">
            <label class="">الاجابة</label>
            <select class="form-control form-control-lg form-control-solid " name="answer">
                <?php $__currentLoopData = $data->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option   <?php if($data1 == $data->answer ): ?> selected <?php endif; ?>  value="<?php echo e($data1); ?>"><?php echo e($data1); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-10">
            <label>الاجابة اخرى</label>
            <textarea rows="5" name="otherAnswer" class="form-control form-control-lg form-control-solid"><?php echo e($data->otherAnswer); ?></textarea>
        </div>
        <?php endif; ?>

        <?php if($data->is_pdf == 1 ): ?>


        <div class="mb-10">
            <!--begin::Label-->
            <label class="col-lg-4 col-form-label fw-bold fs-6">المرفق</label>
            <!--end::Label-->
            <!--begin::Col-->
            <div class="col-lg-8">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title"></h4>
                                <div class="controls">
                                    <input type="file" id="input-file-now" multiple class="dropify"  name="pdf[]" data-default-file="" required data-validation-required-message="<?php echo e(trans('word.This field is required')); ?>"/>
                                </div>
                            </div>
                        </div>
                <!--end::Image input-->
                <!--begin::Hint-->
            
            <!--end::Hint-->
            </div>
            <!--end::Col-->
        </div>

    <?php endif; ?>

    <div class="loader" id="loader" style="display: none"></div>

    <!--end: Wizard Actions-->
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">الغاء</button>
        <button type="submit" class="loading btn btn-primary">حفظ</button>
    </div>
</form>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js" integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!--begin::Page scripts(used by this page) -->
<script>
    $('#kt_select4').select2({
        placeholder: ""
    });
    $('#kt_select5').select2({
        placeholder: ""
    });
</script>
<!--begin::Page scripts(used by this page) -->
<script type="text/javascript">
    $(document).ready(function () {
        // Basic
        $('.dropify').dropify();

        // Used events
        var drEvent = $('#input-file-events').dropify();

        drEvent.on('dropify.beforeClear', function (event, element) {
            return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
        });

        drEvent.on('dropify.afterClear', function (event, element) {
            alert('File deleted');
        });

        drEvent.on('dropify.errors', function (event, element) {
            console.log('Has Errors');
        });

        var drDestroy = $('#input-file-to-destroy').dropify();
        drDestroy = drDestroy.data('dropify')
        $('#toggleDropify').on('click', function (e) {
            e.preventDefault();
            if (drDestroy.isDropified()) {
                drDestroy.destroy();
            } else {
                drDestroy.init();
            }
        })
    });
    $('.loading').on('click',function () {
        document.getElementById("loader").style.display = "block";

        $("#loader").css("display", "block");

    })
    $("#MainCategory2").click(function () {
        var wahda = $(this).val();

        if (wahda != '') {

            $.get("<?php echo e(URL::to('/GetSubCategory')); ?>" + '/' + wahda, function ($data) {
                console.log($data)

                var outs = "";
                $.each($data, function (name, id) {

                    outs += '<option value="' + id + '">' + name + '</option>'

                });
                $('#SubCategory2').html(outs);


            });
        }
    });

</script>
<?php /**PATH D:\laravel\elkalil-laravel\resources\views/admin/Project/levelDetailsModel.blade.php ENDPATH**/ ?>