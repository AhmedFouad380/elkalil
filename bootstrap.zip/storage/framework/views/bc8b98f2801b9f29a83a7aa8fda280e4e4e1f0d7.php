

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(URL::asset('admin/assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <link href="<?php echo e(URL::asset('admin/assets/plugins/custom/prismjs/prismjs.bundle.css')); ?>" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h1 class="d-flex text-dark fw-bolder my-1 fs-3">تفاصيل المشروع</h1>
    <!--end::Title-->
    <!--begin::Breadcrumb-->
    <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-600">
            <a href="<?php echo e(url('/')); ?>" class="text-gray-600 text-hover-primary">لوحة القيادة</a>
        </li>
        <!--end::Item-->
        <li class="breadcrumb-item text-gray-600">
            <a href="<?php echo e(url('/projects')); ?>" class="text-gray-600 text-hover-primary">المشاريع</a>
        </li>
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-500">تفاصيل المشروع</li>
        <!--end::Item-->
    </ul>
    <!--end::Breadcrumb-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
    <!--begin::Post-->
    <div class="content flex-row-fluid" id="kt_content">
        <!--begin::Navbar-->
        <div class="card mb-6 mb-xl-9">
            <div class="card-body pt-9 pb-0">
                <!--begin::Details-->
                <div class="d-flex flex-wrap flex-sm-nowrap mb-6">
                    <!--begin::Image-->
                    <div class="d-flex flex-center flex-shrink-0 bg-light rounded w-100px h-100px w-lg-150px h-lg-150px me-7 mb-4">
                        <img class="mw-50px mw-lg-75px" src="<?php echo e(URL::asset('admin/assets/media/svg/brand-logos/volicity-9.svg')); ?>" alt="image" />
                    </div>
                    <!--end::Image-->
                    <!--begin::Wrapper-->
                    <div class="flex-grow-1">
                        <!--begin::Head-->
                        <div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
                            <!--begin::Details-->
                            <div class="d-flex flex-column">
                                <!--begin::Status-->
                                <div class="d-flex align-items-center mb-1">
                                    <a href="#" class="text-gray-800 text-hover-primary fs-2 fw-bolder me-3">مشروع فيلا الساحل</a>
                                    <span class="badge badge-light-success me-auto">عقد قياسي </span>
                                </div>
                                <!--end::Status-->
                                <!--begin::Description-->
                                <div class="d-flex flex-wrap fw-bold mb-4 fs-5 text-gray-400">اسم مالك المشروع</div>
                                <!--end::Description-->
                            </div>
                            <!--end::Details-->
                        </div>
                        <!--end::Head-->
                        <!--begin::Info-->
                        <div class="d-flex flex-wrap justify-content-start">
                            <!--begin::Stats-->
                            <div class="d-flex flex-wrap">
                                <!--begin::Stat-->
                                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                                    <!--begin::Number-->
                                    <div class="d-flex align-items-center">
                                        <div class="fs-4 fw-bolder">29 Jan, 2021</div>
                                    </div>
                                    <!--end::Number-->
                                    <!--begin::Label-->
                                    <div class="fw-bold fs-6 text-gray-400">تاريخ بداية العقد</div>
                                    <!--end::Label-->
                                </div>
                                <!--end::Stat-->
                                <!--begin::Stat-->
                                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                                    <!--begin::Number-->
                                    <div class="d-flex align-items-center">
                                        <div class="fs-4 fw-bolder">29 Jan, 2021</div>
                                    </div>
                                    <!--end::Number-->
                                    <!--begin::Label-->
                                    <div class="fw-bold fs-6 text-gray-400">تاريخ نهاية العقد</div>
                                    <!--end::Label-->
                                </div>
                                <!--end::Stat-->
                                <!--begin::Stat-->
                                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                                    <!--begin::Number-->
                                    <div class="d-flex align-items-center">
                                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr066.svg-->
                                        <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
                                                <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
                                            </svg>
                                        </span>
                                        <!--end::Svg Icon-->
                                        <div class="fs-4 fw-bolder" data-kt-countup="true" data-kt-countup-value="15000" data-kt-countup-prefix="SAR">0</div>
                                    </div>
                                    <!--end::Number-->
                                    <!--begin::Label-->
                                    <div class="fw-bold fs-6 text-gray-400">اجمالي مبلغ التعاقد</div>
                                    <!--end::Label-->
                                </div>
                                <!--end::Stat-->
                            </div>
                            <!--end::Stats-->
                            <!--begin::Users-->
                            <div class="symbol-group symbol-hover mb-3">
                                <!--begin::User-->
                                <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="Michael Eberon">
                                    <img alt="Pic" src="<?php echo e(URL::asset('admin/assets/media/avatars/150-12.jpg')); ?>" />
                                </div>
                                <!--end::User-->
                                <!--begin::User-->
                                <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="Michelle Swanston">
                                    <img alt="Pic" src="<?php echo e(URL::asset('admin/assets/media/avatars/150-13.jpg')); ?>" />
                                </div>
                                <!--end::User-->
                                <!--begin::User-->
                                <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="Francis Mitcham">
                                    <img alt="Pic" src="<?php echo e(URL::asset('admin/assets/media/avatars/150-5.jpg')); ?>" />
                                </div>
                                <!--end::User-->
                                <!--begin::User-->
                                <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="Melody Macy">
                                    <img alt="Pic" src="<?php echo e(URL::asset('admin/assets/media/avatars/150-3.jpg')); ?>" />
                                </div>
                                <!--end::User-->
                                <!--begin::User-->
                                <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="Barry Walter">
                                    <img alt="Pic" src="<?php echo e(URL::asset('admin/assets/media/avatars/150-7.jpg')); ?>" />
                                </div>
                                <!--end::User-->
                                <!--begin::All users-->
                                <a href="#" class="symbol symbol-35px symbol-circle" data-bs-toggle="modal" data-bs-target="#kt_modal_view_users">
                                    <span class="symbol-label bg-dark text-inverse-dark fs-8 fw-bolder" data-bs-toggle="tooltip" data-bs-trigger="hover" title="رؤية العاملين على المشروع">+</span>
                                </a>
                                <!--end::All users-->
                            </div>
                            <!--end::Users-->
                        </div>
                        <!--end::Info-->
                    </div>
                    <!--end::Wrapper-->
                </div>
                <!--end::Details-->
                <div class="separator"></div>
                <!--begin::Nav wrapper-->
                <div class="d-flex overflow-auto h-55px">
                    <!--begin::Nav links-->
                    <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">مراحل المشروع</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6 active" href="#">بيانات المشروع</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">العاملين على المشروع</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">المحادثات</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">ملفات المشروع</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">الشروحات</a>
                        </li>
                        <!--end::Nav item-->
                        <!--begin::Nav item-->
                        <li class="nav-item">
                            <a class="nav-link text-active-primary me-6" href="#">الاعدادات</a>
                        </li>
                        <!--end::Nav item-->
                    </ul>
                    <!--end::Nav links-->
                </div>
                <!--end::Nav wrapper-->
            </div>
        </div>
        <!--end::Navbar-->

        <!--begin::Row-->
        <div class="row g-6 g-xl-9">
            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">بيانات العميل</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>
            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">عرض السعر</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">رقـم الجـوال :</td>
                                <td class="text-gray-800">966552590399</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>
            
            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">المعلومات المالية</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>

            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">العقد</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>
            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">الاستبيان المبدئي</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">رقـم الجـوال :</td>
                                <td class="text-gray-800">966552590399</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">البريـد الالكتـروني :</td>
                                <td class="text-gray-800">trdlkjopnuu019@gmail.com</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">الخدمـة المطلـوبة :</td>
                                <td class="text-gray-800">VICBANK</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">البلـد :</td>
                                <td class="text-gray-800">داخل المملكة العربية السعودية</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">المدينة :</td>
                                <td class="text-gray-800">منطقة الرياض</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">كيف تم الاستدلال علينا ؟</td>
                                <td class="text-gray-800">اخرى</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">نوع المشروع :</td>
                                <td class="text-gray-800">فيلا سكنية</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">مساحة المشروع :</td>
                                <td class="text-gray-800">اكبر من 250 م</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">ما هي الفترة المتوقعة المراد فيها استلام التصميم :</td>
                                <td class="text-gray-800">من 3 أشهر إلى 6 أشهر</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">نعمل في الخليل على دراسة توفير مخططات شخصية جاهزة للمنازل هل تفضل ذلك:</td>
                                <td class="text-gray-800">نعم</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>
            <div class="col-md-4 col-xxl-3">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card body-->
                    <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <h2 class="fw-bolder mb-10">استبيان المشاريع</h2>
                        <table class="table table-flush fw-bold gy-1">
                            <tbody><tr>
                                <td class="text-muted min-w-125px w-125px">اسـم الكريـم :</td>
                                <td class="text-gray-800">محمد محمد</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">اسـم المشـروع :</td>
                                <td class="text-gray-800">مشروع خيالي فقط</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">رقـم الجـوال :</td>
                                <td class="text-gray-800">966552590399</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">البريـد الالكتـروني :</td>
                                <td class="text-gray-800">trdlkjopnuu019@gmail.com</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">الخدمـة المطلـوبة :</td>
                                <td class="text-gray-800">VICBANK</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">البلـد :</td>
                                <td class="text-gray-800">داخل المملكة العربية السعودية</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">المدينة :</td>
                                <td class="text-gray-800">منطقة الرياض</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">كيف تم الاستدلال علينا ؟</td>
                                <td class="text-gray-800">اخرى</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">نوع المشروع :</td>
                                <td class="text-gray-800">فيلا سكنية</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">مساحة المشروع :</td>
                                <td class="text-gray-800">اكبر من 250 م</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">ما هي الفترة المتوقعة المراد فيها استلام التصميم :</td>
                                <td class="text-gray-800">من 3 أشهر إلى 6 أشهر</td>
                            </tr>
                            <tr>
                                <td class="text-muted min-w-125px w-125px">نعمل في الخليل على دراسة توفير مخططات شخصية جاهزة للمنازل هل تفضل ذلك:</td>
                                <td class="text-gray-800">نعم</td>
                            </tr>
                        </tbody></table>
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
            </div>
        </div>
        <!--end::Row-->

    </div>
    <!--end::Post-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/js/custom/widgets.js')); ?>"></script>

    <script type="text/javascript">
        $(function () {
            var table = $('#users_table').DataTable({
                processing: true,
                serverSide: true,
                autoWidth: false,
                responsive: true,
                aaSorting: [],
                "dom": "<'card-header border-0 p-0 pt-6'<'card-title' <'d-flex align-items-center position-relative my-1'f> r> <'card-toolbar' <'d-flex justify-content-end add_button'B> r>>  <'row'l r> <''t><'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>", // horizobtal scrollable datatable
                 lengthMenu: [[10, 25, 50, 100, 250, -1], [10, 25, 50, 100, 250, "الكل"]],
                "language": {
                    search: '<i class="fa fa-eye" aria-hidden="true"></i>',
                    searchPlaceholder: 'بحث سريع',
                    "url": "<?php echo e(url('admin/assets/ar.json')); ?>"
                },
                buttons: [
                    {extend: 'print', className: 'btn btn-light-primary me-3', text: '<i class="bi bi-printer-fill fs-2x"></i>'},
                    // {extend: 'pdf', className: 'btn btn-raised btn-danger', text: 'PDF'},
                    {extend: 'excel', className: 'btn btn-light-primary me-3', text: '<i class="bi bi-file-earmark-spreadsheet-fill fs-2x"></i>'},
                    // {extend: 'colvis', className: 'btn secondary', text: 'إظهار / إخفاء الأعمدة '}

                ],
                ajax: {
                    url: '<?php echo e(route('employee.datatable.data')); ?>',
                    data: {
                        <?php if(Request::get('users_group')): ?>
                        users_group: <?php echo e(Request::get('users_group')); ?>

                        ,
                        <?php endif; ?>
                            <?php if(Request::get('jop_type')): ?>
                        jop_type:<?php echo e(Request::get('jop_type')); ?>

                        <?php endif; ?>
                    }
                },
                columns: [
                    {data: 'checkbox', name: 'checkbox', "searchable": false, "orderable": false},
                    {data: 'name', name: 'name', "searchable": true, "orderable": true},
                    {data: 'jop_type', name: 'jop_type', "searchable": true, "orderable": true},
                    {data: 'users_group', name: 'users_group', "searchable": true, "orderable": true},
                    {data: 'is_active', name: 'is_active', "searchable": true, "orderable": true},
                    {data: 'actions', name: 'actions', "searchable": false, "orderable": false},

                ]
            });

            $.ajax({
                url: "<?php echo e(URL::to('/add-button')); ?>",
                success: function (data) { $('.add_button').append(data); },
                dataType: 'html'
            });

            $("#kt_daterangepicker_1").daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    minYear: 1901,
                    maxYear: parseInt(moment().format("YYYY"),10)
                }, function(start, end, label) {
                    var years = moment().diff(start, "years");
                    alert("You are " + years + " years old!");
                }
            );

            $("#kt_daterangepicker_2").daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    minYear: 1901,
                    maxYear: parseInt(moment().format("YYYY"),10)
                }, function(start, end, label) {
                    var years = moment().diff(start, "years");
                    alert("You are " + years + " years old!");
                }
            );
        });
    </script>


    <?php
    $message = session()->get("message");
    ?>

    <?php if( session()->has("message")): ?>
        <script>
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": true,
                "progressBar": true,
                "positionClass": "toast-bottom-right",
                "preventDuplicates": false,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };

            toastr.success("نجاح", "<?php echo e($message); ?>");
        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\elkalil-laravel\resources\views/admin/project_details4.blade.php ENDPATH**/ ?>