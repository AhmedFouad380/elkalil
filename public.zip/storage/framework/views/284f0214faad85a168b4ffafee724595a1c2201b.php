

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        @media (min-width: 992px) {
            .aside-me .content {
                padding-right: 30px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h1 class="d-flex text-dark fw-bolder my-1 fs-3">تعديل بيانات عميل</h1>
    <!--end::Title-->
    <!--begin::Breadcrumb-->
    <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-600">
            <a href="<?php echo e(url('/')); ?>" class="text-gray-600 text-hover-primary">لوحة القيادة</a>
        </li>
        <!--end::Item-->
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-500">قائمة العملاء</li>
        <li class="breadcrumb-item text-gray-500">تعديل بيانات عميل</li>
        <!--end::Item-->
    </ul>
    <!--end::Breadcrumb-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
        <!--begin::Post-->
        <?php echo $__env->make('admin.setting.kt_aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content flex-row-fluid" id="kt_content">

            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                     data-bs-target="#kt_account_profile_details" aria-expanded="true"
                     aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">تعديل بيانات عميل</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_settings_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form id="kt_account_profile_details_form" action="<?php echo e(url('update-client')); ?>" class="form"
                          method="post">
                    <?php echo csrf_field(); ?>
                    <!--begin::Card body-->
                        <div class="card-body border-top p-9">
                            <!--begin::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">اسم العميل</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="name"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="الاسم" value="<?php echo e($employee->name); ?>" required/>

                                <input type="hidden" name="id" value="<?php echo e($employee->id); ?>" required/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">البريد الالكترونى</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="email" name="email"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="البريد الالكتروني" value="<?php echo e($employee->email); ?>"
                                       required/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">رقم الجوال</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="tel" name="phone"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="رقم الجوال" value="<?php echo e($employee->phone); ?>" required/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">كلمة المرور</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="password" name="password"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="كلمة المرور" value=""/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">تأكيد كلمة المرور</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="password" name="password_confirmation"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="تأكيد كلمة المرور" value=""/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">العنوان</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="address"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="العنوان" value="<?php echo e($employee->address); ?>"/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->

                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <label for="exampleFormControlInput1"
                                       class="form-label">المنطقة</label>
                                <select class="form-control form-control-solid mb-3 mb-lg-0"
                                        name="state" aria-label="" required id="state">
                                    <option value="">اختر المنطقة</option>
                                    <?php $__currentLoopData = \App\Models\State::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->state == $state->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($state->id); ?>"><?php echo e($state->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <!--end::Input group-->

                            <div class="fv-row mb-7">
                                <label for="exampleFormControlInput1"
                                       class="form-label">الفرع</label>
                                <select class="form-control form-control-solid mb-3 mb-lg-0"
                                        name="branche" aria-label="" required id="branche">
                                    <option value="">اختر الفرع</option>
                                    <?php $__currentLoopData = \App\Models\Branche::where('state',$employee->state)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->branche == $branche->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($branche->id); ?>"><?php echo e($branche->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <div
                                    class="form-check form-switch form-check-custom form-check-solid">
                                    <label class="form-check-label" for="flexSwitchDefault">مفعل
                                        ؟</label>
                                    <input class="form-check-input" name="is_active" type="hidden"
                                           value="0" id="flexSwitchDefault"/>
                                    <input class="form-check-input form-control form-control-solid mb-3 mb-lg-0"
                                           name="is_active" type="checkbox"
                                           value="1" id="flexSwitchDefault"
                                           <?php if($employee->is_active == 1): ?> checked <?php endif; ?> />
                                </div>
                            </div>
                            <!--end::Input group-->


                        </div>
                        <!--end::Scroll-->
                        <!--begin::Actions-->

                        <div class="card-footer d-flex justify-content-end py-6 px-9">
                            <button type="reset" class="btn btn-light btn-active-light-primary me-2">الغاء</button>
                            <button type="submit" class="btn btn-primary" id="kt_account_profile_details_submit">حفظ
                            </button>
                        </div>
                        <!--end::Actions-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->

        </div>
        <!--end::Post-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $("#state").change(function () {
            var wahda = $(this).val();

            if (wahda != '') {
                $.get("<?php echo e(URL::to('/get-branch')); ?>" + '/' + wahda, function ($data) {
                    var outs = "";
                    $.each($data, function (title, id) {
                        console.log(title)
                        outs += '<option value="' + id + '">' + title + '</option>'
                    });
                    $('#branche').html(outs);
                });
            }
        });
    </script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\elkalil-laravel\resources\views/admin/setting/clients/edit.blade.php ENDPATH**/ ?>