<script>var hostUrl = "<?php echo e(asset('admin/assets/')); ?>";</script>
<!--begin::Javascript-->
<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="<?php echo e(asset('admin/assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/scripts.bundle.js')); ?>"></script>
<!--end::Global Javascript Bundle-->
<!--begin::Page Custom Javascript(used by this page)-->
<?php echo $__env->yieldContent('script'); ?>
<!--end::Page Custom Javascript-->

<?php
$errors = session()->get("errors");
?>

<?php if( session()->has("errors")): ?>
    <?php
    $e = implode(' - ', $errors->all());
    ?>

    <script>
        Swal.fire({
            icon: 'warning',
            title: "برجاء التأكد من البيانات.",
            text: "<?php echo e($e); ?> ",
            type: "error",
            timer: 5000,
            showConfirmButton: false
        });
    </script>

<?php endif; ?>


<!--end::Javascript-->

<?php /**PATH D:\laravel\elkalil-laravel\resources\views/admin/layouts/footer-script.blade.php ENDPATH**/ ?>