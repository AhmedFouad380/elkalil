<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeKnowUs extends Model
{
    use HasFactory;

    protected  $table = 'se_know_us';

    protected $fillable = [
        'title',


    ];
}
